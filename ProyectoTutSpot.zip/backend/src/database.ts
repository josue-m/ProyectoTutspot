import mongoose from 'mongoose';
import config from './config';

(async () => {
  try {
    await mongoose.connect(
        `mongodb+srv://josueror:Mabel2506@proyecto.yq3uma1.mongodb.net/ProyectoTut`
    );

    console.log('Connected to TutSpot');
  } catch (error) {
    console.error(error);
  }
})();