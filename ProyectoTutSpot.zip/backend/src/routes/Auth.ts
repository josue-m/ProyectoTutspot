import { Router } from 'express';
import { login } from '../controllers/Login';

const AuthRouter = Router();

// Ruta para iniciar sesión
AuthRouter.post('/api/login', login);

export default AuthRouter;
