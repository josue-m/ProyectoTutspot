import { Router } from "express";
import { getAllMateria, getMateriaById, createMateria, deleteMateria } from "../controllers/MateriaController";


const Materiarouter = Router();

Materiarouter.get('/api/materia/get-all-materia', getAllMateria);
Materiarouter.get('/api/materia/get-materia-by-id/:id', getMateriaById)
Materiarouter.post('/api/materia/create-materia', createMateria);
Materiarouter.delete('/api/materia/deletebyID/:id', deleteMateria)

export default Materiarouter;