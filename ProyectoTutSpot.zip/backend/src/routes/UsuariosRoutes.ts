import { Router } from "express";
import { getAllUsers, getUserById, createUser, deleteUser } from "../controllers/UserControllers";


const Userrouter = Router();

Userrouter.get('/api/users/get-all-users', getAllUsers);
Userrouter.get('/api/users/get-user-by-id/:id', getUserById)
Userrouter.post('/api/users/create-user', createUser);
Userrouter.delete('/api/users/deletebyID/:id', deleteUser)

export default Userrouter;