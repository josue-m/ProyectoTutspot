import { Schema, model } from 'mongoose';

const materiaSchema = new Schema(
  {
    tema: { type: String, trim: true },
    fecha: {type: Date, trim: true},
    descripcion: { type: String, trim: true},
    precio: {type: String, trim: true},
    foto: {type: String, trim: true},
  },

  {
    versionKey: false,
    collection: 'Materia'
  }
);

export default model('Materia', materiaSchema);