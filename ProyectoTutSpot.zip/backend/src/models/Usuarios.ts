import mongoose, { Schema, model } from 'mongoose';

const userSchema = new Schema(
  {
    nombre: { type: String, trim: true, required: true },
    apellido: { type: String, trim: true, required: true },
   correo: { type: String, required: true },
   password: { type: String, required: true },
    rol: { type: String, enum: ['alumno', 'tutor'], required: true },
  },

  {
    versionKey: false,
    collection: 'Users'
  }
);

export default model('Users', userSchema);