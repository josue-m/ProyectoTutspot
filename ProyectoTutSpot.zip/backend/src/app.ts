import express from 'express';
import config from './config';
import cors from 'cors';
import morgan from 'morgan';
import Userrouter from './routes/UsuariosRoutes';
import AuthRouter from './routes/Auth';
import Materiarouter from './routes/MateriaRoutes';

const app = express();

app.set('port', config.MONGO_PORT);

app.use(morgan('dev'));
app.use(cors({
    origin: 'http://localhost:3000',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
  }));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(Userrouter);
app.use(AuthRouter);
app.use(Materiarouter);

export default app;