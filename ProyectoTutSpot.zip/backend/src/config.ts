console.log(process.env.MONGO_USERNAME)

export default {
  MONGO_PORT: 4200,
  MONGO_USERNAME: process.env.MONGO_USERNAME,
  MONGO_PASSWORD: process.env.MONGO_PASSWORD,
  MONGO_DATABASE: process.env.MONGO_DATABASE,
};