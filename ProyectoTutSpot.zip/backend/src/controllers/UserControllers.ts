import Users from "../models/Usuarios";
import { Request, Response } from 'express';
import bcrypt from 'bcrypt';

const getAllUsers = async (req: Request, res: Response) => {
    try {
      const user = await Users.find();
      res.json(user);
    } catch (error) {
      res.json(error);
    }
  };

  const getUserById = async (req: Request, res: Response) => {
    const { id } =req.params;
    try {
      const user = await Users.findById(id);
      res.json(user);
    } catch (error) {
      res.json(error);
    }
  }

  const createUser = async (req: Request, res: Response) => {
    const { nombre, apellido, correo, password, rol} = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const newUser = new Users({
        nombre,
        apellido,
        correo,
        password: hashedPassword,
        rol,
    });
    try {
      const user = await newUser.save();
      res.json(user);
    } catch (error) {
      res.json(error);
    }
  }

  const deleteUser = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
      const user = await Users.findById(id);
      const deletebyID = await Users.deleteOne({ _id: user?.id })
      res.json(deletebyID);
    } catch (error) {
      res.json(error);
    }
  }

  export { getAllUsers, getUserById, createUser, deleteUser };