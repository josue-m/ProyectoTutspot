import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import Users from '../models/Usuarios';

const login = async (req: Request, res: Response) => {
  const { correo, password } = req.body;

  try {
    // Buscar usuario por correo electrónico 
    const usuario = await Users.findOne({ correo });

    if (!usuario) {
      return res.status(401).json({ message: 'Usuario incorrecto' });
    }

    // Comparar contraseñas
    const contrasenaValida = await bcrypt.compare(password, usuario.password);

    if (!contrasenaValida) {
      return res.status(401).json({ message: 'Contraseña incorrecta' });
    }

    // Generar token JWT
    const token = jwt.sign({ userId: usuario._id, tipoUsuario: usuario.rol }, 'secreto', { expiresIn: '1h' });

    if (usuario.rol === 'alumno') {
      res.status(200).json({ message: 'Inicio de sesión exitoso', token, tipoUsuario: usuario.rol });
    } else if (usuario.rol === 'tutor') {
      res.status(200).json({ message: 'Inicio de sesión exitoso', token, tipoUsuario: usuario.rol });
    } else {
      // Manejar otros roles si es necesario
      res.status(200).json({ message: 'Inicio de sesión exitoso', token });
    }
  } catch (error) {
    console.error('Error al iniciar sesión:', error);
    res.status(500).json({ message: 'Error del servidor' });
  }
};

export { login };
