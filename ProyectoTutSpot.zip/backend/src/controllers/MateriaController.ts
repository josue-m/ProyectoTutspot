import Materia from "../models/Materia";
import { Request, Response } from 'express';

const getAllMateria = async (req: Request, res: Response) => {
    try {
      const materia = await Materia.find();
      res.json(materia);
    } catch (error) {
      res.json(error);
    }
  };

  const getMateriaById = async (req: Request, res: Response) => {
    const { id } =req.params;
    try {
      const materia = await Materia.findById(id);
      res.json(materia);
    } catch (error) {
      res.json(error);
    }
  }

  const createMateria = async (req: Request, res: Response) => {
    const { tema, fecha, descripcion, precio, foto} = req.body;
    const newMateria = new Materia({
        tema,
        fecha,
        descripcion,
        precio,
        foto,
    });
    try {
      const materia = await newMateria.save();
      res.json(materia);
    } catch (error) {
      res.json(error);
    }
  }

  const deleteMateria = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
      const materia = await Materia.findById(id);
      const deletebyID = await Materia.deleteOne({ _id: materia?.id })
      res.json(deletebyID);
    } catch (error) {
      res.json(error);
    }
  }

  export { getAllMateria, getMateriaById, createMateria, deleteMateria };