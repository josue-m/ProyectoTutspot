import React, { useEffect, useState } from 'react';
import './Tutoria.css'; 
import { useParams } from 'react-router-dom';
import { apiConnection } from '../../apiconnection/apiconnection';
import { Materia } from '../../interfaces/Materia';


function Tutoria() {
    const { materiaId } = useParams<{ materiaId: string }>();
    const [materia, setMateria] = useState<Materia | null>(null);

    useEffect(() => {
        const fetchMateria = async () => {
            try {
                console.log("Este es mi ID", materiaId)
                const response = await apiConnection.get<Materia>(`/materia/get-materia-by-id/${materiaId}`);
                setMateria(response.data);
            } catch (error) {
                console.error('Error fetching materia:', error);
            }
        };

        fetchMateria();
    }, [materiaId]);

    if (!materia) {
        return <div>Loading...</div>;
    }

    return (

        <><header id="header" className="d-flex align-items-center">
            <div className="container d-flex justify-content-between align-items-center">
                <div className="logo">
                    <h1>
                        <a href="/">TutSpot</a>
                    </h1>
                </div>
                <nav id="navbar" className="navbar">
                    <ul>
                        <li>
                            <a href="/alumno">Tutorias Disponibles</a>
                        </li>
                        <li>
                            <a href="/">Cerrar Sesion</a>
                        </li>
                    </ul>
                    <i className="bi bi-list mobile-nav-toggle"></i>
                </nav>
            </div>
        </header><div className="container px-4 px-lg-5 my-5">
                <div className="row gx-4 gx-lg-5 align-items-center">
                 
                    <div className="col-md-6">
                        <div className="small mb-1"> </div>
                        <div className="input-group mt-2">
                            <h1 className="display-5 fw-bolder"> </h1>
                            <div className="fs-5 mb-5">
                                <br></br>
                                <h2 className="display-5 fw-bolder">{materia.tema}</h2>
                                <span>Lps. {materia.precio}</span>
                                <p className="lead">Fecha: {materia.fecha.toString()}</p> 
                            </div>
                            <p className="lead">{materia.descripcion}</p>
                            <div className="d-flex"></div>
                            <a className="btn-get-started animate__animated animate__fadeInUp" href={`/pago/${materia._id}`}>Reservar</a>
                        </div>
                    </div>
                </div>
            </div></>
    );
}

export default Tutoria;
