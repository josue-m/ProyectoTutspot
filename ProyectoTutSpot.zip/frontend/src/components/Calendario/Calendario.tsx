import React, { useState } from 'react';
import './Calendario.css';

interface Event {
  date: number;
  color: string;
}

const Calendario: React.FC = () => {
  const [month, setMonth] = useState<string>('March');
  const [year, setYear] = useState<number>(2024);

  const months: string[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const years: number[] = Array.from({ length: 10 }, (_, i) => new Date().getFullYear() + i);

  const events: Event[] = [
    { date: 5, color: 'blue' },
    { date: 10, color: 'green' },
    { date: 15, color: 'orange' },
    { date: 20, color: 'red' },
    { date: 25, color: 'purple' }
  ];

  const handleMonthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setMonth(e.target.value);
  };

  const handleYearChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setYear(parseInt(e.target.value));
  };

  const daysInMonth = (month: number, year: number): number => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getStartingDayOfMonth = (month: number, year: number): number => {
    return new Date(year, month, 1).getDay();
  };

  const generateCalendarDays = (): JSX.Element[] => {
    const totalDays = daysInMonth(months.indexOf(month), year);
    const startingDay = getStartingDayOfMonth(months.indexOf(month), year);
    const days: JSX.Element[] = [];

    // Add empty slots for days before the starting day of the month
    for (let i = 0; i < startingDay; i++) {
      days.push(<li key={`empty-${i}`} className="empty-day"></li>);
    }

    // Add calendar days with event indicators
    for (let i = 1; i <= totalDays; i++) {
      const event = events.find(e => e.date === i);
      const eventIndicator = event ? <div className={`event-indicator bg-${event.color}`}></div> : null;
      days.push(
        <li key={i}>
          <div className="date">{i}</div>
          {eventIndicator}
        </li>
      );
    }

    return days;
  };

  return (
    <>
      <header id="header" className="d-flex align-items-center">
          <div className="container d-flex justify-content-between align-items-center">
            <div className="logo">
              <h1>
                <a href="/">TutSpot</a>
              </h1>
            </div>
            <nav id="navbar" className="navbar">
              <ul>
                <li>
                  <a href="/tutor">Crear Tutoria</a>
                </li>
                <li>
                  <a href="/perfiltutor">Cuenta</a>
                </li>
                <li>
                  <a href="/calendario">Calendario</a>
                </li>
                <li>
                  <a href="/">Cerrar Sesion</a>
                </li>
              </ul>
              <i className="bi bi-list mobile-nav-toggle"></i>
            </nav>
          </div>
        </header>
      

      <div className="container py-5">
              {/* For Demo Purpose */}
              <header className="text-center text-white mb-5">
                  <h1 className="display-4">Bootstrap Calendar</h1>
                  <p className="font-italic mb-0">A nicely-designed Bootstrap calendar widget. This calendar is just for design purposes; you can make it work.</p>
                  <p className="font-italic">Snippet By <a href="https://bootstrapious.com" className="text-white">
                      <u>Bootstrapious</u></a>
                  </p>
              </header>

              {/* Month and Year Selection */}
              <div className="d-flex justify-content-center mb-3">
                  <select className="form-select me-2" value={month} onChange={handleMonthChange}>
                      {months.map((m, index) => (
                          <option key={index} value={m}>{m}</option>
                      ))}
                  </select>
                  <select className="form-select" value={year} onChange={handleYearChange}>
                      {years.map((y, index) => (
                          <option key={index} value={y}>{y}</option>
                      ))}
                  </select>
              </div>

              {/* Calendar */}
              <div className="calendar shadow bg-white p-5">
                  <div className="d-flex align-items-center"><i className="fa fa-calendar fa-3x mr-3"></i>
                      <h2 className="month font-weight-bold mb-0 text-uppercase">{month} {year}</h2>
                  </div>
                  <p className="font-italic text-muted mb-5">No events for this day.</p>
                  <ol className="day-names list-unstyled">
                      <li className="font-weight-bold text-uppercase">Sun</li>
                      <li className="font-weight-bold text-uppercase">Mon</li>
                      <li className="font-weight-bold text-uppercase">Tue</li>
                      <li className="font-weight-bold text-uppercase">Wed</li>
                      <li className="font-weight-bold text-uppercase">Thu</li>
                      <li className="font-weight-bold text-uppercase">Fri</li>
                      <li className="font-weight-bold text-uppercase">Sat</li>
                  </ol>

                  <ol className="days list-unstyled">
                      {generateCalendarDays()}
                  </ol>
              </div>
          </div></>
  );
};

export default Calendario;
