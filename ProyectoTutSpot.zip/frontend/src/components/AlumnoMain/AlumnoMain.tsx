import React, { useState, useEffect } from 'react';
import './AlumnoMain.css'; 
import { Materia } from '../../interfaces/Materia';
import { apiConnection } from '../../apiconnection/apiconnection';

const AlumnoMain: React.FC = () => {
  const [tutorias, setTutorias] = useState<Materia[]>([]);

  useEffect(() => {
    const fetchTutorias = async () => {
      try {
        const response = await apiConnection.get<Materia[]>('/materia/get-all-materia');
        setTutorias(response.data);
      } catch (error) {
        console.error('Error fetching tutorias:', error);
      }
    };

   

    fetchTutorias();
  }, []);

  return (
    <div>
      <header id="header" className="d-flex align-items-center">
        <div className="container d-flex justify-content-between align-items-center">
          <div className="logo">
            <h1>
              <a href="/">TutSpot</a>
            </h1>
          </div>
          <nav id="navbar" className="navbar">
            <ul>
              <li>
                <a href="/perfilalumno">Cuenta</a>
              </li>
              <li>
                <a href="/">Cerrar Sesion</a>
              </li>
            </ul>
            <i className="bi bi-list mobile-nav-toggle"></i>
          </nav>
        </div>
      </header>

      <br></br>

      <div className="container">
        <div className="row">
          {tutorias.map(materia => (
            
              <div className="card mb-4">
                <div className="card-body">
                  <h2 className="card-title">{materia.tema}</h2>
                  <p className="card-text">{materia.descripcion}</p>
                  <div className="small text-muted">LPS: {materia.precio}</div>
                  <a className="btn-get-started animate__animated animate__fadeInUp" href={`/tutoria/${materia._id}`}>Ver más →</a>
                </div>
              </div>
            
          ))}
        </div>
      </div>
    </div>
  );
};

export default AlumnoMain;
