import axios from 'axios';

const baseURL = 'http://localhost:4200/api';
export const apiConnection = axios.create({baseURL});