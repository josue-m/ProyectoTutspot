export interface Usuarios {
    nombre: string;
    apellido: string;
    password: string;
    correo: string;
    rol: string;
  }