export interface Materia {
  _id: string;  
  tema: string;
    fecha: Date;
    descripcion: string;
    precio: string;
    foto: string;
  }